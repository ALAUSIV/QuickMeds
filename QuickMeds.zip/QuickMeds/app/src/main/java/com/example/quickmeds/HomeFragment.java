package com.example.quickmeds;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class HomeFragment extends Fragment {

    TextView greetingText;

    View cardAppointment, cardPrescriptions, cardRecords, cardPharmacy, cardHealthHistory, cardForum;
    FloatingActionButton emergencyFab;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Greeting
        greetingText = view.findViewById(R.id.greetingText);
        greetingText.setText(getGreeting("Alex"));

        // Grid cards
        cardAppointment = view.findViewById(R.id.cardAppointment);
        cardPrescriptions = view.findViewById(R.id.cardPrescriptions);
        cardRecords = view.findViewById(R.id.cardRecords);
        cardPharmacy = view.findViewById(R.id.cardPharmacy);
        cardHealthHistory = view.findViewById(R.id.cardHealthHistory);
        cardForum = view.findViewById(R.id.cardForum);

        emergencyFab = view.findViewById(R.id.emergencyFab);

        // Navigation
        cardAppointment.setOnClickListener(v -> startActivity(new Intent(getActivity(), AppointmentActivity.class)));
        cardPrescriptions.setOnClickListener(v -> startActivity(new Intent(getActivity(), PrescriptionActivity.class)));
        cardRecords.setOnClickListener(v -> startActivity(new Intent(getActivity(), MedicalRecordsActivity.class)));
        cardPharmacy.setOnClickListener(v -> startActivity(new Intent(getActivity(), PharmacyLocatorActivity.class)));
        cardHealthHistory.setOnClickListener(v -> startActivity(new Intent(getActivity(), HealthTimelineActivity.class))); // NEW
        cardForum.setOnClickListener(v -> startActivity(new Intent(getActivity(), ForumActivity.class)));

        emergencyFab.setOnClickListener(v ->
                Toast.makeText(getContext(), "Dialing Emergency Services...", Toast.LENGTH_SHORT).show()
        );

        return view;
    }

    private String getGreeting(String name) {
        int hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        if (hour >= 5 && hour < 12) return "Good morning, " + name + "!";
        else if (hour >= 12 && hour < 17) return "Good afternoon, " + name + "!";
        else return "Good evening, " + name + "!";
    }
}
