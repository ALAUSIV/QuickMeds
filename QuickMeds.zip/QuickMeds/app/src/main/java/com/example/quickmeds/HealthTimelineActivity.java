package com.example.quickmeds;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class HealthTimelineActivity extends AppCompatActivity {

    ListView timelineList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_timeline);

        timelineList = findViewById(R.id.timelineList);


        String[] history = {
                "✔️ March 15 - Prescription Refill: Amoxicillin",
                "📅 March 10 - Appointment with Dr. Smith (Cardiology)",
                "🧾 March 5 - Lab Test Results Added",
                "📅 Feb 20 - Video Consultation with Nurse Anne",
                "💊 Feb 1 - Medication Reminder: Metformin",
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, history);
        timelineList.setAdapter(adapter);
    }
}
